![截屏2020-03-16下午3.20.48](/Users/war/Library/Application Support/typora-user-images/截屏2020-03-16下午3.20.48.png)

**我完成了以上这些点，我在macOS上用xcode写的，我的虚拟机炸了。我把框架改了一部分，比如图片文件路径，执行各个部分的也变了。**![截屏2020-03-16下午3.24.37](/Users/war/Library/Application Support/typora-user-images/截屏2020-03-16下午3.24.37.png)

**我用上图的部分代替了**![截屏2020-03-16下午3.25.15](/Users/war/Library/Application Support/typora-user-images/截屏2020-03-16下午3.25.15.png)

![截屏2020-03-16下午3.25.53](/Users/war/Library/Application Support/typora-user-images/截屏2020-03-16下午3.25.53.png)

**并且路径我也修改了，可能导致你无法在虚拟机上复现我的结果。**

